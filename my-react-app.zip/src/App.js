import React, { useState, useEffect, useMemo } from 'react';
import { ethers } from 'ethers';
import axios from 'axios';
import crypto from 'crypto-browserify';

const contractABI = require('./SettlementsAndCrossBorderPayment.json').abi;
const contractAddress = process.env.CONTRACT_ADDRESS || '0xbAa72205413fdc573Dc58FB7cB144D21567669C9';

function App() {
  const [depositAmount, setDepositAmount] = useState('');
  const [userAddress, setUserAddress] = useState('');
  const [counterparty, setCounterparty] = useState('');
  const [securitiesAmount, setSecuritiesAmount] = useState('');
  const [cashAmount, setCashAmount] = useState('');
  const [currentAccount, setCurrentAccount] = useState(null);
  const [kycStatus, setKycStatus] = useState(null);
  const [riskProfile, setRiskProfile] = useState(null);
  const [settlements, setSettlements] = useState([]);
  const [newUserParams, setNewUserParams] = useState({
    name: '',
    idType: '',
    idNumber: '',
    dayOfBirth: '',
    monthOfBirth: '',
    yearOfBirth: '',
  });
  const [hash, setHash] = useState(null);

  const handleNewUserParams = (event) => {
    setNewUserParams({
      ...newUserParams,
      [event.target.name]: event.target.value,
    });
  };

  useEffect(() => {
    if (typeof window.ethereum !== 'undefined') {
      window.ethereum.request({ method: 'eth_requestAccounts' })
        .then(accounts => {
          setCurrentAccount(accounts[0]);
          console.log('Connected account:', accounts[0]);
        })
        .catch(error => {
          console.error('Error accessing accounts:', error);
        });

      window.ethereum.on('accountsChanged', function (accounts) {
        setCurrentAccount(accounts[0]);
        console.log('Accounts changed, new account:', accounts[0]);
      });

      window.ethereum.on('chainChanged', (chainId) => {
        window.location.reload();
      });

      return () => {
        window.ethereum.removeListener('accountsChanged', () => {});
        window.ethereum.removeListener('chainChanged', () => {});
      };
    } else {
      console.error('Please install MetaMask!');
    }
  }, []);

  const provider = useMemo(() => new ethers.providers.Web3Provider(window.ethereum), []);
  const signer = useMemo(() => provider.getSigner(), [provider]);
  const contract = useMemo(() => {
    if (!contractAddress) {
      return null;
    }
    return new ethers.Contract(contractAddress, contractABI, signer);
  }, [signer]);

  useEffect(() => {
    async function fetchData() {
      if (currentAccount) {
        try {
          const kycStatus = await contract.kycVerified(currentAccount);
          setKycStatus(kycStatus);
        } catch (error) {
          console.error('Error fetching KYC status:', error);
        }
      }
    }
    fetchData();
  }, [currentAccount, contract]);

  const handleDeposit = async () => {
    try {
      const txResponse = await contract.deposit({ value: ethers.utils.parseEther(depositAmount) });
      const receipt = await txResponse.wait();
      alert('Deposit successful!');
      axios.post('http://localhost:3002/log', {
        transactionHash: receipt.transactionHash,
        amount: depositAmount,
      });
    } catch (error) {
      console.error('Error during deposit:', error);
      alert('Deposit failed!');
    }
  };

  const handleVerifyKYC = async () => {
    try {
      const hash = crypto.createHash('sha256');
      hash.update(`${newUserParams.name}${newUserParams.idType}${newUserParams.idNumber}${newUserParams.dayOfBirth}${newUserParams.monthOfBirth}${newUserParams.yearOfBirth}`);
      setHash(hash.digest('hex'));
      await axios.post('http://localhost:3001/contract/verifyKYC', {
        address: userAddress,
        name: newUserParams.name,
        idType: newUserParams.idType,
        idNumber: newUserParams.idNumber,
        dayOfBirth: newUserParams.dayOfBirth,
        monthOfBirth: newUserParams.monthOfBirth,
        yearOfBirth: newUserParams.yearOfBirth,
      });
    } catch (error) {
      console.error('Error verifying KYC:', error);
      alert('Hash for KYC ZKP proofing successfully created, Data not stored yet on database!');
    }
  };

  const handleInitiateSettlement = async () => {
    try {
      const settlementId = await contract.initiateSettlement(counterparty, ethers.utils.parseUnits(securitiesAmount, 'wei'), ethers.utils.parseUnits(cashAmount, 'wei'));
      alert(`Settlement initiated with ID: ${settlementId}`);
      axios.post('http://localhost:3002/log', {
        eventType: 'Settlement Initiation',
        settlementId: settlementId.toString(),
        initiatorAddress: currentAccount,
        counterpartyAddress: counterparty,
        securitiesAmount: securitiesAmount,
        cashAmount: cashAmount,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Error initiating settlement:', error);
      alert('Settlement initiation failed!');
    }
  };

  const handleRiskProfile = async () => {
    try {
      const riskProfileResponse = await contract.profileRisk(userAddress, 100, true, true);
      setRiskProfile(riskProfileResponse);
    } catch (error) {
      console.error('Error profiling risk:', error);
    }
  };

  const handleGetSettlements = async () => {
    try {
      const settlementsResponse = await contract.getSettlements();
      setSettlements(settlementsResponse);
    } catch (error) {
      console.error('Error fetching settlements:', error);
    }
  };

  return (
    <div style={{ backgroundColor: '#BBDEFB', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', color: '#0D47A1' }}>
        Settlement and Cross Border Payments DApp
      </h1>
      {contractAddress ? (
        <div style={{ backgroundColor: '#E3F2FD', padding: '20px', borderRadius: '8px', margin: '20px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <input
            type="text"
            value={depositAmount}
            onChange={e => setDepositAmount(e.target.value)}
            placeholder="Amount in ETH to Deposit"
          />
          <button onClick={handleDeposit}>Deposit</button>
          <input
            type="text"
            value={userAddress}
            onChange={e => setUserAddress(e.target.value)}
            placeholder="User Address for KYC"
          />
          <button onClick={handleVerifyKYC}>Verify KYC</button>
          <input
            type="text"
            value={counterparty}
            onChange={e => setCounterparty(e.target.value)}
            placeholder="Counterparty Address"
          />
          <input
            type="text"
            value={securitiesAmount}
            onChange={e => setSecuritiesAmount(e.target.value)}
            placeholder="Securities Amount"
          />
          <input
            type="text"
            value={cashAmount}
            onChange={e => setCashAmount(e.target.value)}
            placeholder="Cash Amount"
          />
          <button onClick={handleInitiateSettlement}>Initiate Settlement</button>
          <button onClick={handleRiskProfile}>Get Risk Profile</button>
          <button onClick={handleGetSettlements}>Get Settlements</button>
          <div>
            <h2>KYC Status: {kycStatus ? 'Verified' : 'Not Verified'}</h2>
            <h2>Risk Profile: {riskProfile ? JSON.stringify(riskProfile) : 'Not Available'}</h2>
            <h2>Settlements:</h2>
            <ul>
              {settlements.map((settlement, index) => (
                <li key={index}>{settlement.initiator} - {settlement.counterparty}</li>
              ))}
            </ul>
          </div>
          <h2>Hash: {hash}</h2>
        </div>
      ) : (
        <p>Contract address is not set.</p>
      )}
      <form>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={newUserParams.name}
            onChange={handleNewUserParams}
          />
        </label>
        <label>
          ID Type:
          <input
            type="text"
            name="idType"
            value={newUserParams.idType}
            onChange={handleNewUserParams}
          />
        </label>
        <label>
          ID Number:
          <input
            type="text"
            name="idNumber"
            value={newUserParams.idNumber}
            onChange={handleNewUserParams}
          />
        </label>
        <label>
          Day of Birth:
          <input
            type="text"
            name="dayOfBirth"
            value={newUserParams.dayOfBirth}
            onChange={handleNewUserParams}
          />
        </label>
        <label>
          Month of Birth:
          <input
            type="text"
            name="monthOfBirth"
            value={newUserParams.monthOfBirth}
            onChange={handleNewUserParams}
          />
        </label>
        <label>
          Year of Birth:
          <input
            type="text"
            name="yearOfBirth"
            value={newUserParams.yearOfBirth}
            onChange={handleNewUserParams}
          />
        </label>
        <button type="button" onClick={handleVerifyKYC}>Submit</button>
      </form>
    </div>
  );
}

export default App;
