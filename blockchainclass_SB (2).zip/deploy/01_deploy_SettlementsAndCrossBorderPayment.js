const { ethers } = require("hardhat");

const deploySettlementsAndCrossBorderPayment = async ({ deployments, getNamedAccounts }) => {
  const { deploy } = deployments;
  const { deployer } = await getNamedAccounts();

  console.log("Deploying contracts with the account:", deployer);

  const SettlementsAndCrossBorderPayment = await deploy("SettlementsAndCrossBorderPayment", {
    from: deployer,
    args: [],
    log: true,
  });

  console.log(`SettlementsAndCrossBorderPayment contract deployed to: ${SettlementsAndCrossBorderPayment.address}`);
};

module.exports.default = deploySettlementsAndCrossBorderPayment;


