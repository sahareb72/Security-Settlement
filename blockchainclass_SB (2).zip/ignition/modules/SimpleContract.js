const { buildModule } = require("@nomicfoundation/hardhat-ignition/modules");

module.exports = buildModule("SimpleContractModule", (m) => {
  // Deploy the SimpleContract without constructor arguments
  const simpleContract = m.contract("SimpleContract");

  return { simpleContract };
});




