const { ethers } = require("hardhat");

const deploySecuritiesSettlement = async ({ deployments, getNamedAccounts }) => {
  const { deploy } = deployments;
  const { deployer } = await getNamedAccounts();

  console.log("Deploying contracts with the account:", deployer);

  const securitiesSettlement = await deploy("SecuritiesSettlement", {
    from: deployer,
    args: [],
    log: true,
  });

  console.log(`SecuritiesSettlement deployed to: ${securitiesSettlement.address}`);
};

module.exports.default = deploySecuritiesSettlement; // Note the use of .default for export
